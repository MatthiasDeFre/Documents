package domein;

import java.math.BigDecimal;

public class Zichtrekening {

    private BigDecimal saldo;

    public Zichtrekening()
    {
        this.saldo = BigDecimal.ZERO;
    }

    public BigDecimal getSaldo()
    {
        return this.saldo;
    }

    /**
     *
     * @param bedrag
     */
    public void storten(BigDecimal bedrag)
    {
        // TODO - implement Zichtrekening.storten
        if(bedrag == null  || bedrag.signum() < 0)
            throw new IllegalArgumentException();
        saldo = saldo.add(bedrag);
    }

}

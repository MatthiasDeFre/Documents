/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unitTests;

import java.math.BigDecimal;
import org.junit.Test;
import org.junit.Assert;

/**
 *
 * @author Matthias
 */
import domein.Zichtrekening;
import org.junit.Before;

public class ZichrekeningTest {

    private Zichtrekening rekening;

    @Before
    public void before()
    {
        rekening = new Zichtrekening();
    }

    @Test
    public void stortenMoetSaldoAanpassen()
    {
        BigDecimal bedrag = new BigDecimal(200);

        rekening.storten(bedrag);
        Assert.assertEquals(bedrag, rekening.getSaldo());

    }

    @Test
    public void nieuweRekeningSaldoLeeg()
    {

        Assert.assertEquals(BigDecimal.ZERO, rekening.getSaldo());

    }
    
    @Test(expected = IllegalArgumentException.class) 
    public void stortenMetNegatiefBedrag() {
        rekening.storten(new BigDecimal(-100));
    }

    
    @Test(expected = IllegalArgumentException.class) 
    public void stortenMetNull() {
        rekening.storten(null);
    }
}
            
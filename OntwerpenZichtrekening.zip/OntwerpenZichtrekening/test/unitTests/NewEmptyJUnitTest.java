/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unitTests;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Matthias
 */
public class NewEmptyJUnitTest {
    
    public NewEmptyJUnitTest()
    {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
